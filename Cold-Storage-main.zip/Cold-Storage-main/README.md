# Cold-Storage
Farmers can book the slot for storing cotton or chilli
